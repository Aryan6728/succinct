import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { PlayerInput } from './components/PlayerInput';
import { ImageDisplay } from './components/ImageDisplay';
import { StoryBlock } from './components/StoryBlock';
import { LoadingIndicator } from './components/LoadingIndicator';
import { GameOverScreen } from './components/GameOverScreen';
import { generateStoryAndImage } from './services/geminiService';
import type { StoryTurn } from './types';

const App: React.FC = () => {
  const [history, setHistory] = useState<StoryTurn[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);

  const storyContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    storyContainerRef.current?.scrollTo({
        top: storyContainerRef.current.scrollHeight,
        behavior: 'smooth'
    });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history]);

  const startGame = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setIsGameOver(false);
    setHistory([]);
    try {
      const initialData = await generateStoryAndImage([], 'The adventure begins.');
      setHistory([{
        id: Date.now(),
        action: 'Your journey starts...',
        outcome: initialData.outcome,
        scene: initialData.scene,
        imageB64: initialData.imageB64
      }]);
    } catch (e) {
      console.error(e);
      setError('Failed to start a new adventure. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    startGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePlayerAction = async (action: string) => {
    if (!action.trim() || isLoading || isGameOver) return;

    setIsLoading(true);
    setError(null);
    
    // Add player action immediately for better UX
    const newHistory: StoryTurn[] = [
        ...history, 
        {
            id: Date.now(),
            action: action,
            outcome: "...",
            scene: "...",
            imageB64: history[history.length-1]?.imageB64 ?? ''
        }
    ];
    setHistory(newHistory);

    try {
      const gameData = await generateStoryAndImage(history, action);
      
      const updatedHistoryTurn: StoryTurn = {
        id: Date.now(),
        action,
        outcome: gameData.outcome,
        scene: gameData.scene,
        imageB64: gameData.imageB64,
      };

      setHistory(prev => [...prev.slice(0, prev.length -1), updatedHistoryTurn]);
      
      if (gameData.gameOver) {
        setIsGameOver(true);
      }
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`The ancient magic falters. ${errorMessage} Try a different path.`);
      setHistory(prev => prev.slice(0, prev.length -1)); // Revert optimistic update
    } finally {
      setIsLoading(false);
    }
  };
  
  const currentImage = history.length > 0 ? history[history.length - 1].imageB64 : '';
  const isInitialLoading = isLoading && history.length === 0;

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col">
      <Header />
      {isGameOver && <GameOverScreen onRestart={startGame} />}
      <main className="flex-grow container mx-auto p-4 grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
        <div className="lg:col-span-2 lg:sticky lg:top-4">
          <ImageDisplay imageB64={currentImage} isLoading={isLoading} />
        </div>

        <div className="lg:col-span-3 flex flex-col h-[calc(100vh-200px)] bg-black bg-opacity-20 rounded-lg shadow-2xl">
            {isInitialLoading ? (
                <div className="flex-grow flex flex-col items-center justify-center p-8 text-center">
                    <LoadingIndicator />
                    <p className="mt-4 text-lg text-indigo-300 animate-pulse">Summoning a new world...</p>
                </div>
            ) : (
                <div ref={storyContainerRef} className="flex-grow overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
                    {history.map((turn, index) => (
                        <StoryBlock key={turn.id} turn={turn} isLast={index === history.length - 1 && isLoading} />
                    ))}
                    {isLoading && !isInitialLoading && <LoadingIndicator />}
                </div>
            )}
           
            <div className="p-4 border-t border-gray-700">
                 {error && <p className="text-red-400 mb-2 text-center">{error}</p>}
                <PlayerInput onSend={handlePlayerAction} disabled={isLoading || isGameOver} />
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;
