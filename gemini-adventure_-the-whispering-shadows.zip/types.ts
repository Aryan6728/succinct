export interface StoryTurn {
  id: number;
  action: string;
  outcome: string;
  scene: string;
  imageB64: string;
}

export interface GameData {
  scene: string;
  outcome: string;
  gameOver: boolean;
  imagePrompt: string;
}
