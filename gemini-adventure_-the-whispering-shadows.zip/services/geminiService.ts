import { GoogleGenAI, Type } from "@google/genai";
import type { StoryTurn } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        scene: {
            type: Type.STRING,
            description: "A detailed, atmospheric description of the new situation, environment, and any characters. Should be 2-3 sentences."
        },
        outcome: {
            type: Type.STRING,
            description: "A description of what happened as a direct result of the player's action. Should be 1-2 sentences."
        },
        gameOver: {
            type: Type.BOOLEAN,
            description: "True if the player has died, reached a definitive end, or the story is otherwise over. False otherwise."
        },
        imagePrompt: {
            type: Type.STRING,
            description: "A rich, detailed visual prompt for an image generator. Focus on the environment, characters, and mood. Use keywords like 'dark fantasy', 'epic lighting', 'cinematic'. Example: 'A lone knight stands before a colossal, moss-covered stone gate in a misty, ancient forest, glowing runes pulse with faint blue light on the door, cinematic lighting, epic fantasy art.'"
        }
    },
    required: ["scene", "outcome", "gameOver", "imagePrompt"]
};


const generateStoryPrompt = (history: StoryTurn[], playerAction: string): string => {
    let context = `You are a master storyteller for a dark fantasy text adventure game.
    The user provides an action, and you must generate the next part of the story.
    The story should be engaging, descriptive, and reactive to the player's choices.
    The game ends if the player dies or reaches a conclusion.
    Always respond in the required JSON format.
    
    Previous story context:
    `;

    if (history.length === 0) {
        context += "This is the very beginning of the adventure.\n";
    } else {
        const recentHistory = history.slice(-3); // Use last 3 turns for context
        recentHistory.forEach(turn => {
            context += `Scene: ${turn.scene}\nPlayer Action: ${turn.action}\nOutcome: ${turn.outcome}\n\n`;
        });
    }

    context += `Now, the player takes the following action: "${playerAction}"\n
    Generate the next part of the story based on this action.`;

    return context;
};

export const generateStoryAndImage = async (history: StoryTurn[], playerAction: string) => {
    const prompt = generateStoryPrompt(history, playerAction);

    // Generate story text and image prompt
    const storyResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
            temperature: 0.8,
        }
    });

    const storyText = storyResponse.text;
    if (!storyText) {
        throw new Error("The story suddenly ended. The AI returned no text.");
    }

    let gameData;
    try {
        gameData = JSON.parse(storyText);
    } catch (error) {
        console.error("Failed to parse JSON from Gemini:", storyText);
        throw new Error("The fabric of reality shimmers and breaks. The AI's response was malformed.");
    }


    if (gameData.gameOver) {
        return {
            ...gameData,
            imageB64: '' // No need to generate an image for the game over screen
        };
    }

    // Generate image
    const imageResponse = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: gameData.imagePrompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: '16:9',
        },
    });

    const imageB64 = imageResponse.generatedImages[0]?.image?.imageBytes;

    if (!imageB64) {
        throw new Error("The world fades to black. The AI failed to generate an image.");
    }
    
    return {
        ...gameData,
        imageB64: imageB64
    };
};
