import React, { useState } from 'react';

interface PlayerInputProps {
  onSend: (action: string) => void;
  disabled: boolean;
}

export const PlayerInput: React.FC<PlayerInputProps> = ({ onSend, disabled }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !disabled) {
      onSend(inputValue);
      setInputValue('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center space-x-3">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder={disabled ? 'Awaiting the next chapter...' : 'What do you do?'}
        disabled={disabled}
        className="flex-grow bg-gray-800 border border-gray-600 rounded-md py-2 px-4 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        aria-label="Player action input"
      />
      <button
        type="submit"
        disabled={disabled || !inputValue.trim()}
        className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-md hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:opacity-50"
        aria-label="Send action"
      >
        Send
      </button>
    </form>
  );
};
