import React from 'react';
import type { StoryTurn } from '../types';

interface StoryBlockProps {
  turn: StoryTurn;
  isLast: boolean;
}

const TypewriterText: React.FC<{ text: string }> = ({ text }) => {
    // This is a simple render, a full typewriter effect can be complex
    // and might be distracting with frequent updates.
    // CSS-based animations could be an alternative.
    return <p>{text}</p>;
};

export const StoryBlock: React.FC<StoryBlockProps> = ({ turn, isLast }) => {
  return (
    <div className="p-4 rounded-lg bg-gray-800/50 shadow-md transition-all duration-300 ease-in-out transform hover:scale-[1.02]">
      {turn.action && (
        <div className="border-l-4 border-indigo-500 pl-4 mb-3">
          <p className="font-bold text-indigo-300 italic">You: "{turn.action}"</p>
        </div>
      )}
      {turn.outcome && (
         <div className="mb-3 text-gray-300">
            {isLast ? <TypewriterText text={turn.outcome} /> : <p>{turn.outcome}</p>}
        </div>
      )}
      {turn.scene && (
        <div className="text-gray-200">
           {isLast ? <TypewriterText text={turn.scene} /> : <p>{turn.scene}</p>}
        </div>
      )}
    </div>
  );
};
