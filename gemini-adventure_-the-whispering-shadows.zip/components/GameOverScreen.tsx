import React from 'react';

interface GameOverScreenProps {
  onRestart: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({ onRestart }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex flex-col items-center justify-center z-50 animate-fade-in">
      <h2 className="text-6xl font-medieval text-red-500 mb-4">Game Over</h2>
      <p className="text-xl text-gray-300 mb-8">Your tale has come to an end.</p>
      <button
        onClick={onRestart}
        className="bg-indigo-600 text-white font-bold py-3 px-8 rounded-md text-lg hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-300 transform hover:scale-105"
      >
        Begin a New Legend
      </button>
    </div>
  );
};

// Add fade-in animation to tailwind config or a style tag if needed.
// For simplicity, a simple style tag is not used here but could be.
// e.g. @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
// .animate-fade-in { animation: fadeIn 0.5s ease-in-out; }
