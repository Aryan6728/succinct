import React from 'react';
import { Feather } from 'lucide-react'; // Using an icon library for aesthetics

const QuillIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-indigo-400">
        <path d="M20.7 14.9a1 1 0 0 0-1.4-1.4l-3.6 3.6a1 1 0 0 0 0 1.4l.7.7a1 1 0 0 0 1.4 0l3-3a1 1 0 0 0-.1-1.7z"></path>
        <path d="m14 7 3 3"></path>
        <path d="M12 11.5c-2.2 0-4-2.3-4-5.2s1.8-5.2 4-5.2 4 2.3 4 5.2c0 .2 0 .3 0 .4"></path>
        <path d="M5 22c-1.7 0-3-1.3-3-3s1.3-3 3-3c.4 0 .9.1 1.3.3"></path>
    </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="py-4 px-6 bg-gray-900/50 backdrop-blur-sm border-b border-gray-700/50 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-center text-center">
        <QuillIcon />
        <h1 className="ml-3 text-3xl font-medieval font-bold text-gray-100 tracking-wider">
          Gemini Adventure: <span className="text-indigo-400">The Whispering Shadows</span>
        </h1>
      </div>
    </header>
  );
};
