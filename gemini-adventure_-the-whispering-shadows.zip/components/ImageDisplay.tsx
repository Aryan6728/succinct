import React from 'react';

interface ImageDisplayProps {
  imageB64: string;
  isLoading: boolean;
}

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageB64, isLoading }) => {
  const imageUrl = imageB64 ? `data:image/jpeg;base64,${imageB64}` : '';

  return (
    <div className="relative aspect-video bg-black rounded-lg shadow-lg overflow-hidden border border-gray-700">
      {isLoading && !imageB64 && (
        <div className="absolute inset-0 bg-gray-800 animate-pulse"></div>
      )}
      {imageUrl && (
        <img
          src={imageUrl}
          alt="Current scene"
          className="w-full h-full object-cover transition-opacity duration-500 ease-in-out"
          style={{ opacity: isLoading ? 0.7 : 1 }}
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/10"></div>
       {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
           <div className="w-16 h-16 border-4 border-t-transparent border-indigo-400 rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
};
