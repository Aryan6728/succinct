import React from 'react';

export const LoadingIndicator: React.FC = () => {
  return (
    <div className="flex justify-center items-center p-4">
      <div className="flex items-center space-x-2 text-gray-400">
         <div className="w-4 h-4 border-2 border-t-transparent border-indigo-400 rounded-full animate-spin"></div>
         <span>The mists of fate are swirling...</span>
      </div>
    </div>
  );
};
